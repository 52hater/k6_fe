document.addEventListener("click", () => ) {

let arr = [];

while (i <= 45) {
    arr.push(i);
    i++;
}

let arr2 = [];

while (arr2.length <= 6){
    let rand = Math.floor(Math.random() * arr.length) + 1;
    arr2.push(arr[rand]);
}

document.getElementById().

}
